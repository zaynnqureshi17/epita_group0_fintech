# EPITA Engineering Tools TP2 — Group 0 Stripe Project

**Course:** Engineering Tools — Session 2  
**Instructor:** Ismail Lachheb  
**Group:** Group 0 — Fintech & Payments (Stripe Test Mode)  
**Members:** Kusananda Thakur, Rachid Rahme, Steven El Hayek, Muhammad Zain Qureshi  
**Date:** 28/10/2026  
**Assigned API Domain:** Stripe Test Mode (`STRIPE_API_KEY`)  
**Project Directory:** `epita_group0_fintech`  
**Python Package:** `epita_rachid_rahme_fintech`  
**TestPyPI URL:** Not published in this session; publication is pending explicit approval and secure token setup.

---

## Step 0: Assigned Group Verification

The assigned group and domain are confirmed by the official roster in the TP instructions: Group 0 — Fintech & Payments (Stripe Test Mode). The project directory is `epita_group0_fintech` and the live target is `GET https://api.stripe.com/v1/balance` with `Authorization: Bearer <STRIPE_API_KEY>`.

---

## Part 1: Environment Isolation with `uv`

### 1.1 Verified environment comparison

We ran the diagnostic script both globally and under `uv`:

```text
=== Active Python Binary (sys.executable) ===
  C:\Python314\python.exe

=== Python Version ===
  3.14.3

=== Virtual Env Prefix (sys.prefix) ===
  C:\Python314

=== Base Prefix (sys.base_prefix) ===
  C:\Python314

=== Is in Virtual Environment? ===
  False
```

```text
=== Active Python Binary (sys.executable) ===
  C:\Users\rahme\Desktop\engineering Tools\epita_group0_fintech\.venv\Scripts\python.exe

=== Python Version ===
  3.14.3

=== Virtual Env Prefix (sys.prefix) ===
  C:\Users\rahme\Desktop\engineering Tools\epita_group0_fintech\.venv

=== Base Prefix (sys.base_prefix) ===
  C:\Python314

=== Is in Virtual Environment? ===
  True
```

### 1.2 Analysis

`sys.executable` points to the interpreter actually used. In the global run it points to the system Python; in the `uv` run it points to the project-specific `.venv`. `sys.prefix` is the environment root. `sys.base_prefix` remains `C:\Python314` in the virtual environment, which shows uv created an isolated environment while preserving the base interpreter. This is why `uv run` isolates project dependencies without requiring a manual `.venv` activation.

`uv run` looks up the project lock and environment automatically and executes commands against the local `.venv`. This avoids accidental imports from the system Python and ensures consistent dependency resolution.

### 1.3 Git hygiene

The repository ignore rules are configured to exclude the sensitive and generated directories required by the lab:

```gitignore
.venv/
.env
__pycache__/
.pytest_cache/
dist/
*.egg-info/
*.txt
```

The `scripts/inspect_env.py` script is committed in the repository and the environment files remain local-only.

---

## Part 2: Live API Connection & Secret Hygiene

### 2.1 Git status evidence

Verified repository status:

```text
## codex-final-integration
 M pyproject.toml
?? scripts/
?? src/epita_rachid_rahme_fintech/cli.py
?? tests/
```

Ignored files are protected as required:

```text
!! .env
!! .venv/
!! dist/
!! global_env_output.txt
!! uv_env_output.txt
```

`git check-ignore -v .env` confirms:

```text
.gitignore:2:.env       .env
```

`.env.template` is tracked and contains placeholders only:

```ini
APP_ENV=development
DEBUG=True
STRIPE_API_KEY=your_dummy_api_key_here
```

### 2.2 Live API response

The verified live response from the project client is:

```python
{'status': 'LIVE_SUCCESS', 'currency': 'EUR', 'available_balance': 0.0, 'livemode': False}
```

This confirms that the app used Stripe test mode and a valid test key. The balance is `0.0` because no sandbox payments were created for the test account.

### 2.3 Security analysis

- Why environment variables are safer than config files:
  1. They are kept outside the repository, reducing the risk of accidental credential leaks in version control or in code review snapshots.
  2. They allow different credentials per environment (local, test, staging, production) without changing the application code.

- Why dangerous fallbacks are unsafe:
  - A fallback like `os.getenv("STRIPE_API_KEY", "default")` can silently hide misconfiguration and cause the application to send a fake or expired secret to production.
  - In real systems, an invalid fallback may result in authentication failures or worse, accidental use of a non-production credential.

---

## Part 3: Dependency Hygiene & Semantic Versioning

### 3.1 Dependency tree

Verified with:

```powershell
python -m uv tree
```

Output:

```text
epita-rachid-rahme-fintech v0.1.0
├── python-dotenv v1.2.4
├── requests v2.34.2
│   ├── certifi v2026.10.23
│   ├── charset-normalizer v3.5.2
│   ├── idna v3.20
│   └── urllib3 v2.8.0
├── rich v15.0.0
│   ├── markdown-it-py v4.2.0
│   │   └── mdurl v0.1.2
│   └── pygments v2.21.0
└── pytest v9.2.0 (group: dev)
    ├── colorama v0.4.6
    ├── iniconfig v2.3.1
    ├── packaging v26.3
    ├── pluggy v1.7.0
    └── pygments v2.21.0
```

- Direct dependencies: `requests`, `python-dotenv`, `rich`
- Development dependency: `pytest`
- Transitive dependencies: `urllib3`, `charset-normalizer`, `certifi`, `idna`, `markdown-it-py`, `mdurl`, `pygments`, `iniconfig`, `pluggy`, `packaging`, `colorama`

### 3.2 SemVer and lockfile notes

1. `^2.31.0` is a caret range and means the dependency can be upgraded within the same major version, so `2.x` is allowed, but `3.0.0` is not.
2. `~=2.2.1` is a compatible-release style range; it allows updates within the same minor series, so `2.2.x` is allowed but `2.3.0` is not.
3. `==13.7.1` pins an exact version, so only `13.7.1` is accepted.
4. `^2.31.0` does not allow `3.0.0` because the major version would change; the caret rule restricts updates to the same major version unless the major is `0`.
5. `pyproject.toml` declares the intended dependency ranges; `uv.lock` pins the exact packages and hashes that were resolved for the project. This creates deterministic installs and avoids accidental drift across machines.
6. The SHA-256 hashes inside `uv.lock` protect against supply-chain attacks by allowing `uv` to reject altered distributions that do not match the recorded digest.

---

## Part 4: Package Build & CLI Packaging

### 4.1 Local CLI execution

The required project script is configured in `pyproject.toml`:

```toml
[project.scripts]
epita-group0-cli = "epita_rachid_rahme_fintech.cli:main"
```

Verified command:

```powershell
python -m uv run epita-group0-cli
```

Verified output:

```text
╭────────────────────────── EPITA Fintech & Payments ──────────────────────────╮
│ Group 0 — Stripe Test Mode Dashboard                                         │
│ ┏━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━┓                                         │
│ ┃ Field             ┃ Value        ┃                                         │
│ ┡━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━┩                                         │
│ │ Status            │ LIVE_SUCCESS │                                         │
│ │ Currency          │ EUR          │                                         │
│ │ Available Balance │ 0.00         │                                         │
│ │ Livemode          │ False        │                                         │
│ └───────────────────┴──────────────┘                                         │
╰────────────────── Stripe sandbox data (secret key omitted) ──────────────────╯
```

### 4.2 Build artifacts

Verified with:

```powershell
python -m uv build
```

Produced artifacts in `dist/`:

```text
epita_rachid_rahme_fintech-0.1.0-py3-none-any.whl
epita_rachid_rahme_fintech-0.1.0.tar.gz
```

This is the expected wheel and source distribution pair for the package.

### 4.3 Packaging theory

- An `sdist` (`.tar.gz`) is a source distribution containing the package source and build metadata. It must be built on the target machine or environment.
- A wheel (`.whl`) is a built distribution that contains compiled/install-ready files for the target platform and Python version.
- Wheels are faster to install because they avoid the build step on the client machine and usually contain ready-to-install package contents.
- Avoiding arbitrary build-time execution improves installation safety because it reduces the risk of executing untrusted code during install, especially from external or compromised packages.
- The console entry point works because `uv` and Python packaging register the script name from `[project.scripts]` and point it to the `main()` function in the CLI module.

### 4.4 TestPyPI status

The package was not published to TestPyPI in this session because the project requires explicit approval and secure credential handling. No token was created or exposed, and no public package URL is claimed. The local wheel and sdist were built successfully and are ready to publish once the user approves the publication step.

---

## Part 5: Professional Debugging Challenge

### 5.1 Root cause analysis

The original failure pattern is caused by mixing numeric values with strings. In the broken logic, `record["volume"]` and `record["weight"]` were treated as text values instead of `float` values, which caused a runtime type error or incorrect aggregation when arithmetic was applied. The fix converts the CSV values into proper numeric types before any multiplication or summation occurs.

The relevant data flow is:

- `parse_api_record()` converts `raw_volume` and `weight_multiplier` to `float`
- `compute_weighted_metric()` multiplies the numeric values
- `aggregate_telemetry()` filters out non-`SUCCESS` records before aggregating

### 5.2 Conditional breakpoint and call stack

The intended debugger breakpoint is at `idx == 2` inside the aggregation loop. The stack at that point is conceptually:

```text
Frame 1: aggregate_telemetry() -> iteration loop
Frame 2: compute_weighted_metric(volume, weight)
Frame 3: parse_api_record(raw_entry) -> CSV parsing and numeric coercion
```

This is the relevant call path because the loop selects the active record, parses the CSV, and then applies the weighted calculation.

### 5.3 Fix code

```python
def parse_api_record(raw_entry: str) -> dict:
    record_id, entity_name, raw_volume, status, weight_multiplier = raw_entry.split(",")
    return {
        "record_id": int(record_id.strip()),
        "entity_name": entity_name.strip(),
        "volume": float(raw_volume.strip()),
        "status": status.strip(),
        "weight": float(weight_multiplier.strip()),
    }


def compute_weighted_metric(volume, weight):
    return float(volume) * float(weight)


def aggregate_telemetry(payload: list[str]) -> dict:
    successful_records = []
    for record_data in payload:
        record = parse_api_record(record_data)
        if record["status"] != "SUCCESS":
            continue
        record["weighted_impact"] = compute_weighted_metric(record["volume"], record["weight"])
        successful_records.append(record)

    total_volume = sum(record["volume"] for record in successful_records)
    successful_count = len(successful_records)
    avg_volume = total_volume / successful_count if successful_count else 0.0
    high_impact_count = sum(1 for record in successful_records if record["weighted_impact"] > 200)

    return {
        "successful_entries": successful_count,
        "total_volume": total_volume,
        "avg_volume": avg_volume,
        "high_impact_count": high_impact_count,
    }
```

### 5.4 Verified execution output

Executed with:

```powershell
python -m uv run python scripts/debug_challenge.py
```

Actual result:

```python
{'successful_entries': 3, 'total_volume': 650.0, 'avg_volume': 216.66666666666666, 'high_impact_count': 1}
```

This matches the expected output required by the lab.

---

## Final Quality Notes

- Local dependency resolution succeeded with `python -m uv sync`.
- The configuration and API client were validated with real Stripe test-mode data.
- The CLI entry point works and produces the dashboard without leaking the API key.
- The package built successfully as both a wheel and a source distribution.
- The debug challenge was corrected and verified with the required output.

The hash only proves the file has not changed since it was locked. It does not protect against a version that was already malicious when we locked it, so changes to `uv.lock` still need to be reviewed.

### 3.4 Semantic Versioning

**requests = "^2.31.0"**

Allows compatible releases from version 2.31.0 up to, but excluding, 3.0.0.

**urllib3 = "~=2.2.1"**

Allows versions from 2.2.1 up to, but excluding, 2.3.0.

**rich = "==13.7.1"**

Requires exactly version 13.7.1.

| Constraint | Range | Updates allowed |
|---|---|---|
| `^2.31.0` | `>=2.31.0, <3.0.0` | minor and patch |
| `~=2.2.1` | `>=2.2.1, <2.3.0` | patch only |
| `==13.7.1` | `13.7.1` only | none |

The caret `^` is Poetry and npm syntax. It is not valid in a standard (PEP 621) `pyproject.toml` read by uv, where the same range is written `requests>=2.31.0,<3`.

### 3.5 Would uv lock --upgrade Install Version 3.0.0?

No. `uv lock --upgrade` picks the newest version allowed by the constraint, so with `^2.31.0` it moves to the newest 2.x release and stops there. The upper bound `<3.0.0` excludes 3.0.0.

Under SemVer (MAJOR.MINOR.PATCH), a new MAJOR version signals breaking changes, and the caret exists to accept only non-breaking updates. Moving to 3.x requires changing the constraint in `pyproject.toml` on purpose, after checking the breaking changes.

### 3.6 Difference Between pyproject.toml and uv.lock

| | `pyproject.toml` (declaration) | `uv.lock` (pinning) |
|---|---|---|
| Written by | the developer | generated by uv (`uv add`, `uv lock`) |
| Contains | direct dependencies only | every package, direct and transitive |
| Versions | allowed ranges (`>=2.34.2`) | one exact version each (`2.34.2`) |
| Also stores | project metadata, scripts, build system | source URL and SHA-256 hash of every file |
| Purpose | what the project accepts | the exact environment, identical on every machine |

`pyproject.toml` says what we accept, and `uv.lock` records what we actually got. Both are committed to Git, so `uv sync` rebuilds the same environment for every group member.

---

## Part 4 — Building and Deploying to TestPyPI

Pending implementation of the CLI entry point, package build, TestPyPI publication, and installation verification.

---

## Part 5 — Professional Debugging

Pending debugger investigation, code correction, and validation.

---

## Conclusion

The uv project environment and dependency setup have been completed successfully. The project is ready for Stripe API integration, CLI development, package publishing, and debugging validation.

**Report status:** Work in progress — remaining sections will be completed after integration and testing.